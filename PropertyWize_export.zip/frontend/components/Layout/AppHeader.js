import { Layout, Menu } from 'antd';
import { 
  HomeOutlined, 
  AppstoreOutlined, 
  FileTextOutlined 
} from '@ant-design/icons';
import Link from 'next/link';
import { useRouter } from 'next/router';

const { Header } = Layout;

const AppHeader = () => {
  const router = useRouter();
  
  // 确定当前选中的菜单项
  const getSelectedKey = () => {
    const pathname = router.pathname;
    
    if (pathname === '/') return 'home';
    if (pathname === '/model-center') return 'model-center';
    if (pathname.startsWith('/property-reports')) return 'reports';
    
    return '';
  };

  return (
    <Header className="header" style={{ position: 'fixed', zIndex: 1, width: '100%', display: 'flex', alignItems: 'center' }}>
      <div className="logo" style={{ color: 'white', fontWeight: 'bold', fontSize: '18px', marginRight: '30px' }}>
        PropertyWize
      </div>
      <Menu 
        theme="dark" 
        mode="horizontal" 
        selectedKeys={[getSelectedKey()]}
        style={{ flex: 1, minWidth: 0 }}
      >
        <Menu.Item key="home" icon={<HomeOutlined />}>
          <Link href="/" legacyBehavior>首页</Link>
        </Menu.Item>
        <Menu.Item key="model-center" icon={<AppstoreOutlined />}>
          <Link href="/model-center" legacyBehavior>模型中心</Link>
        </Menu.Item>
        <Menu.Item key="reports" icon={<FileTextOutlined />}>
          <Link href="/property-reports" legacyBehavior>房产估价报告</Link>
        </Menu.Item>
      </Menu>
    </Header>
  );
};

export default AppHeader; 