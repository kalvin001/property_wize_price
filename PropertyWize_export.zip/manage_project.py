#!/usr/bin/env python
"""
PropertyWize项目管理工具入口脚本
"""
from database.project_cli import main

if __name__ == "__main__":
    main() 