from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, FileResponse, Response
from pydantic import BaseModel, field_validator, ConfigDict
from typing import List, Dict, Any, Optional, Callable, Type, TypeVar
import os
import pandas as pd
import numpy as np
import joblib
from pathlib import Path
import json
from pydantic_core import core_schema
from pydantic.json import pydantic_encoder
import io
from reportlab.lib.pagesizes import letter, A4
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image as RLImage
from reportlab.lib.units import inch
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
import platform
import sys

# 添加项目根目录到sys.path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
try:
    # 导入模型接口和工厂
    from models import ModelFactory, ModelInterface
    MODELS_AVAILABLE = True
    print("成功导入模型模块")
except ImportError:
    MODELS_AVAILABLE = False
    print("未找到模型模块，将使用传统方式加载模型")

# 导入项目管理API
try:
    from .project_api import init_project_api
    PROJECT_API_AVAILABLE = True
    print("成功导入项目管理模块")
except ImportError:
    PROJECT_API_AVAILABLE = False
    print("未找到项目管理模块，将不会启用项目管理功能")

# 添加自定义JSON编码器处理NumPy类型
class NumpyEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, np.integer):
            return int(obj)
        elif isinstance(obj, np.floating):
            return float(obj)
        elif isinstance(obj, np.ndarray):
            return obj.tolist()
        return super(NumpyEncoder, self).default(obj)

# 自定义Pydantic序列化函数
def numpy_serializer(obj):
    if isinstance(obj, np.integer):
        return int(obj)
    elif isinstance(obj, np.floating):
        return float(obj)
    elif isinstance(obj, np.ndarray):
        return obj.tolist()
    return pydantic_encoder(obj)  # 默认的Pydantic序列化

# 创建一个自定义的BaseModel，自动处理NumPy数据类型
class NumpyBaseModel(BaseModel):
    """扩展的基础模型，自动处理NumPy数据类型"""
    
    @classmethod
    def _convert_numpy_types(cls, v):
        if isinstance(v, np.integer):
            return int(v)
        elif isinstance(v, np.floating):
            return float(v)
        elif isinstance(v, np.ndarray):
            return v.tolist()
        elif isinstance(v, dict):
            return {k: cls._convert_numpy_types(val) for k, val in v.items()}
        elif isinstance(v, list):
            return [cls._convert_numpy_types(item) for item in v]
        return v
    
    @field_validator('*')
    @classmethod
    def validate_numpy_types(cls, v):
        return cls._convert_numpy_types(v)
    
    model_config = ConfigDict(
        arbitrary_types_allowed=True,
        json_encoders={
            np.integer: lambda v: int(v),
            np.int64: lambda v: int(v),     # 针对 np.int64 的序列化
            np.floating: lambda v: float(v),
            np.float64: lambda v: float(v),   # 针对 np.float64 的序列化
            np.ndarray: lambda v: v.tolist()
        }
    )

app = FastAPI(title="房产估价API")

# 配置应用JSON序列化
import fastapi.encoders
# 保存原始的jsonable_encoder
original_jsonable_encoder = fastapi.encoders.jsonable_encoder

# 创建一个包装函数，处理NumPy类型
def numpy_jsonable_encoder(obj, *args, **kwargs):
    custom_encoder = kwargs.get('custom_encoder', {})
    # 添加NumPy类型处理
    numpy_encoders = {
        np.integer: lambda v: int(v),
        np.floating: lambda v: float(v),
        np.ndarray: lambda v: v.tolist()
    }
    # 合并编码器
    custom_encoder.update(numpy_encoders)
    kwargs['custom_encoder'] = custom_encoder
    # 调用原始函数
    return original_jsonable_encoder(obj, *args, **kwargs)

# 替换编码器
fastapi.encoders.jsonable_encoder = numpy_jsonable_encoder

# 配置CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # 在生产环境中应当设置为特定域名
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 添加自定义响应类，使用NumpyEncoder处理NumPy类型
class NumpyJSONResponse(JSONResponse):
    def render(self, content: Any) -> bytes:
        return json.dumps(
            content,
            ensure_ascii=False,
            allow_nan=True,
            indent=None,
            separators=(",", ":"),
            cls=NumpyEncoder,
        ).encode("utf-8")

# 设置默认响应类
app.json_response_class = NumpyJSONResponse

# 添加辅助函数，用于在API返回前转换NumPy类型
def convert_numpy_types(obj):
    """递归转换所有NumPy类型为Python原生类型"""
    if isinstance(obj, np.integer):
        return int(obj)
    elif isinstance(obj, np.floating):
        return float(obj)
    elif isinstance(obj, np.ndarray):
        return obj.tolist()
    elif isinstance(obj, dict):
        return {k: convert_numpy_types(v) for k, v in obj.items()}
    elif isinstance(obj, list):
        return [convert_numpy_types(item) for item in obj]
    elif isinstance(obj, tuple):
        return tuple(convert_numpy_types(item) for item in obj)
    elif hasattr(obj, '__dict__'):
        # 处理自定义对象
        return {k: convert_numpy_types(v) for k, v in obj.__dict__.items()}
    return obj

# 数据模型
class PropertyFeatures(NumpyBaseModel):
    features: Dict[str, Any]

class PredictionResult(NumpyBaseModel):
    predicted_price: float
    feature_importance: List[Dict[str, Any]]

# 全局变量
MODEL_PATH = Path("../model/xgb_model.joblib")  # 更新为XGBoost模型路径
# 备选路径，以防主路径不工作
ALTERNATE_MODEL_PATHS = [
    Path("model/xgb_model.joblib"),
    Path("./model/xgb_model.joblib"),
    Path("../../model/xgb_model.joblib"),
    Path(os.path.abspath("../model/xgb_model.joblib"))
]
FEATURE_COLS = []
MODEL = None

# 全局变量，用于存储房产数据
PROPERTIES_DF = None

# 重命名现有的PredictionResult类，以便不冲突
class ModelPredictionResult(NumpyBaseModel):
    predicted_price: float
    feature_importance: List[Dict[str, Any]]

# 添加新的房产相关模型
class Property(NumpyBaseModel):
    prop_id: str
    address: str
    predicted_price: float = 0
    features: Dict[str, Any]

class PropertyDetail(Property):
    feature_importance: List[Dict[str, Any]] = []
    comparable_properties: List[Dict[str, Any]] = []
    price_trends: List[Dict[str, Any]] = []  # 历史价格趋势
    price_range: Dict[str, float] = {}  # 价格预测区间
    neighborhood_stats: Dict[str, Any] = {}  # 周边区域统计
    confidence_interval: Dict[str, float] = {}  # 置信区间
    ai_explanation: Dict[str, Any] = {}  # 更详细的模型解释（重命名避免冲突）
    
    model_config = {
        'protected_namespaces': ()  # 禁用保护命名空间检查
    }

class PropertyListResponse(NumpyBaseModel):
    total: int
    page: int
    page_size: int
    properties: List[Property]

# 模型训练和管理相关的数据模型
class ModelTrainingRequest(NumpyBaseModel):
    model_type: str
    params: Dict[str, Any] = {}
    test_size: float = 0.2
    random_state: int = 42

class ModelTrainingResponse(NumpyBaseModel):
    success: bool
    message: str
    metrics: Optional[Dict[str, float]] = None
    model_path: Optional[str] = None
    
class ModelListResponse(NumpyBaseModel):
    models: List[Dict[str, Any]]

@app.on_event("startup")
async def startup_event():
    """应用启动时的初始化"""
    global TRAINED_MODEL, SAMPLE_DATA, COLUMN_DESCRIPTIONS, RAW_DATA
    
    # 配置CORS
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )
    
    # 注册项目管理API
    if PROJECT_API_AVAILABLE:
        init_project_api(app)
        print("已注册项目管理API路由")
    
    # 加载模型
    model_file = os.path.join('model', 'xgboost_model.pkl')
    
    # 优先使用ModelFactory获取模型
    if MODELS_AVAILABLE:
        try:
            # 尝试从模型工厂获取模型
            TRAINED_MODEL = ModelFactory.get_active_model()
            if TRAINED_MODEL:
                print(f"已从模型工厂加载活跃模型: {TRAINED_MODEL.model_type}")
            else:
                # 回退到传统加载方式
                if os.path.exists(model_file):
                    TRAINED_MODEL = joblib.load(model_file)
                    print(f"已从{model_file}加载模型")
                else:
                    TRAINED_MODEL = None
                    print(f"警告: 未找到模型文件{model_file}")
        except Exception as e:
            print(f"从模型工厂加载模型时出错: {e}")
            # 回退到传统加载方式
            if os.path.exists(model_file):
                TRAINED_MODEL = joblib.load(model_file)
                print(f"已从{model_file}加载模型")
            else:
                TRAINED_MODEL = None
                print(f"警告: 未找到模型文件{model_file}")
    else:
        # 使用传统方式加载模型
        if os.path.exists(model_file):
            TRAINED_MODEL = joblib.load(model_file)
            print(f"已从{model_file}加载模型")
        else:
            TRAINED_MODEL = None
            print(f"警告: 未找到模型文件{model_file}")

@app.get("/")
async def root():
    return {"message": "房产估价API已启动"}

@app.get("/api/health")
async def health_check():
    return {"status": "healthy", "model_loaded": MODEL is not None}

@app.get("/api/model/info")
async def model_info():
    """获取模型信息"""
    if MODEL is None:
        # 不抛出错误，而是返回模型未加载的信息
        return {
            "model_type": "XGBRegressor",
            "model_loaded": False,
            "detail": "模型尚未加载，请检查模型文件路径"
        }
    
    try:
        # 尝试从公共数据目录加载模型指标
        metrics_path = Path("../frontend/public/data/model_metrics.json")
        data_info_path = Path("../frontend/public/data/data_info.json")
        
        model_metrics = {}
        if metrics_path.exists():
            with open(metrics_path, 'r') as f:
                model_metrics = json.load(f)
                
            # 注意：现在所有指标都已在analyze_data.py中计算，不需要在这里重新计算
            # 如果后续有新指标需要添加，可以在这里计算
            
            # 如果没有特征重要性数据，但模型有feature_importances_属性，则添加
            if "feature_importance" not in model_metrics and MODEL is not None and hasattr(MODEL, 'feature_importances_'):
                feature_importances = MODEL.feature_importances_
                sorted_idx = np.argsort(feature_importances)[::-1]
                top_features = []
                
                for i in sorted_idx[:20]:  # 取前20个最重要的特征
                    if i < len(FEATURE_COLS):
                        top_features.append({
                            "feature": FEATURE_COLS[i],
                            "importance": float(feature_importances[i])
                        })
                        
                model_metrics["feature_importance"] = top_features
        
        data_info = {}
        if data_info_path.exists():
            with open(data_info_path, 'r') as f:
                data_info = json.load(f)
        
        return {
            "model_type": "XGBRegressor",  # 更新为XGBoost
            "features_count": len(FEATURE_COLS),
            "feature_names": FEATURE_COLS[:10] + ["..."] if len(FEATURE_COLS) > 10 else FEATURE_COLS,
            "metrics": model_metrics,
            "data_info": data_info
        }
    except Exception as e:
        return {
            "model_type": "XGBRegressor",  # 更新为XGBoost
            "features_count": len(FEATURE_COLS),
            "error": str(e)
        }

@app.get("/api/properties/sample")
async def get_sample_properties():
    """获取样本房产及其分析"""
    sample_path = Path("../frontend/public/data/sample_properties.json")
    if not sample_path.exists():
        raise HTTPException(status_code=404, detail="样本房产数据不存在")
    
    with open(sample_path, 'r') as f:
        sample_properties = json.load(f)
    
    return sample_properties

@app.post("/api/predict")
async def predict_price(property_data: PropertyFeatures):
    """预测房价"""
    if MODEL is None:
        raise HTTPException(status_code=404, detail="模型尚未加载")
    
    try:
        # 将输入特征转换为DataFrame
        features_df = pd.DataFrame([property_data.features])
        
        # 确保所有特征列都存在
        for col in FEATURE_COLS:
            if col not in features_df.columns:
                features_df[col] = 0  # 如果特征不存在，用0填充
        
        # 只保留模型使用的特征，并按正确顺序排列
        features_df = features_df[FEATURE_COLS]
        
        # 确保数据类型正确
        for col in features_df.columns:
            if features_df[col].dtype == 'object':
                # 尝试转换为数值型
                try:
                    features_df[col] = pd.to_numeric(features_df[col], errors='coerce')
                except:
                    # 如果无法转换为数值，将其转换为分类型
                    features_df[col] = features_df[col].astype('category')
            # 处理日期类型
            elif pd.api.types.is_datetime64_any_dtype(features_df[col]):
                print(f"属性列表预测时检测到日期类型列: {col}，将转换为数值")
                # 将日期转换为时间戳（从1970-01-01起的天数）
                features_df[col] = (features_df[col] - pd.Timestamp("1970-01-01")) // pd.Timedelta("1 day")
        
        # 再次检查所有列的类型
        cols_to_drop = []
        for col in features_df.columns:
            if not (pd.api.types.is_numeric_dtype(features_df[col]) or 
                    pd.api.types.is_bool_dtype(features_df[col]) or 
                    pd.api.types.is_categorical_dtype(features_df[col])):
                print(f"警告: 属性列表预测前列 {col} 类型 {features_df[col].dtype} 不被模型支持，将移除")
                cols_to_drop.append(col)
        
        # 移除不支持的列
        if cols_to_drop:
            features_df = features_df.drop(columns=cols_to_drop)
        
        # 使用模型预测
        predicted_price = 0.0
        feature_importance = []
        
        # 检查是否为新模型框架的模型
        if MODELS_AVAILABLE and isinstance(MODEL, ModelInterface):
            # 使用新模型框架的预测方法
            predicted_price = float(MODEL.predict(features_df)[0])
            
            # 获取特征重要性
            try:
                importance_df = MODEL.get_feature_importance()
                top_n = min(10, len(importance_df))
                feature_importance = [
                    {
                        "feature": str(importance_df.iloc[i]["feature"]),
                        "importance": float(importance_df.iloc[i]["importance"]),
                        "value": float(features_df[importance_df.iloc[i]["feature"]].iloc[0])
                        if importance_df.iloc[i]["feature"] in features_df.columns else 0.0
                    }
                    for i in range(top_n)
                ]
            except Exception as e:
                print(f"获取特征重要性时出错: {e}")
        else:
            # 传统模型的预测方法
            predicted_price = float(MODEL.predict(features_df)[0])
            
            # 传统模型的特征重要性计算
            if hasattr(MODEL, 'feature_importances_'):
                importances = MODEL.feature_importances_
                indices = np.argsort(importances)[::-1]
                top_n = min(10, len(FEATURE_COLS))  # 最多返回前10个重要特征
                
                for i in range(top_n):
                    idx = indices[i]
                    feature_name = FEATURE_COLS[idx]
                    importance = importances[idx]
                    feature_value = float(features_df[feature_name].iloc[0]) if feature_name in features_df.columns else 0.0
                    
                    feature_importance.append({
                        "feature": feature_name,
                        "importance": float(importance),
                        "value": feature_value
                    })
        
        return {
            "predicted_price": predicted_price,
            "feature_importance": feature_importance
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"预测过程中出错: {str(e)}")

# 添加获取房产列表的API接口
@app.get("/api/properties", response_model=PropertyListResponse)
async def get_properties(
    page: int = Query(1, ge=1),
    page_size: int = Query(10, ge=1, le=100),
    property_type: Optional[str] = None,
    query: Optional[str] = None
):
    """获取房产列表，支持分页和筛选"""
    if PROPERTIES_DF is None:
        raise HTTPException(status_code=404, detail="房产数据尚未加载")
    
    try:
        # 创建过滤后的数据副本
        filtered_df = PROPERTIES_DF.copy()
        
        # 应用过滤条件
        if property_type and 'prop_type' in filtered_df.columns:
            filtered_df = filtered_df[filtered_df['prop_type'] == property_type]
            
        if query:
            # 搜索地址或ID
            query_lower = query.lower()
            address_mask = filtered_df['std_address'].str.lower().str.contains(query_lower, na=False)
            id_mask = filtered_df['prop_id'].astype(str).str.contains(query_lower, na=False)
            filtered_df = filtered_df[address_mask | id_mask]
        
        # 计算总数
        total = len(filtered_df)
        
        # 应用分页
        start_idx = (page - 1) * page_size
        end_idx = start_idx + page_size
        paged_df = filtered_df.iloc[start_idx:end_idx]
        
        # 构造响应
        properties = []
        for _, row in paged_df.iterrows():
            # 实际的y_label价格
            actual_price = float(row.get('y_label', 0))
            
            # 计算房价预测
            pred_price = 0
            if MODEL is not None and set(FEATURE_COLS).issubset(filtered_df.columns):
                try:
                    features = row[FEATURE_COLS]
                    # 使用模型预测前，确保所有特征数据类型正确
                    features_df = features.to_frame().T
                    
                    # 转换数据类型 - 将object类型转为数值型
                    for col in features_df.columns:
                        if features_df[col].dtype == 'object':
                            # 尝试转换为数值型
                            try:
                                features_df[col] = pd.to_numeric(features_df[col], errors='coerce')
                            except:
                                # 如果无法转换为数值，将其转换为分类型
                                features_df[col] = features_df[col].astype('category')
                        # 处理日期类型
                        elif pd.api.types.is_datetime64_any_dtype(features_df[col]):
                            print(f"属性列表预测时检测到日期类型列: {col}，将转换为数值")
                            # 将日期转换为时间戳（从1970-01-01起的天数）
                            features_df[col] = (features_df[col] - pd.Timestamp("1970-01-01")) // pd.Timedelta("1 day")
                    
                    # 再次检查所有列的类型
                    cols_to_drop = []
                    for col in features_df.columns:
                        if not (pd.api.types.is_numeric_dtype(features_df[col]) or 
                                pd.api.types.is_bool_dtype(features_df[col]) or 
                                pd.api.types.is_categorical_dtype(features_df[col])):
                            print(f"警告: 属性列表预测前列 {col} 类型 {features_df[col].dtype} 不被模型支持，将移除")
                            cols_to_drop.append(col)
                    
                    # 移除不支持的列
                    if cols_to_drop:
                        features_df = features_df.drop(columns=cols_to_drop)
                    
                    # 使用模型预测
                    pred_price = float(MODEL.predict(features_df)[0])
                     
                except Exception as e:
                    print(f"预测异常: {e}") 
            else:  
                print(f"模型不可用，使用随机预测: {pred_price}")
            
            # 创建属性字典
            features = {}
            for col in row.index:
                if col not in ['prop_id', 'std_address']:
                    val = row[col]
                    features[col] = float(val) if isinstance(val, (int, float)) and not np.isnan(val) else (
                        str(val) if not pd.isna(val) else None
                    )
            
            properties.append(Property(
                prop_id=str(row['prop_id']),
                address=row['std_address'],
                predicted_price=pred_price,
                features=features
            ))
        
        return PropertyListResponse(
            total=total,
            page=page,
            page_size=page_size,
            properties=convert_numpy_types(properties)
        )
    
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"获取房产列表出错: {str(e)}")

# 添加获取单个房产详情的API接口
@app.get("/api/properties/{prop_id}", response_model=PropertyDetail)
async def get_property_detail(prop_id: str):
    """获取单个房产的详情"""
    if PROPERTIES_DF is None:
        raise HTTPException(status_code=404, detail="房产数据尚未加载")
    
    try:
        # 查找指定ID的房产
        prop_df = PROPERTIES_DF[PROPERTIES_DF['prop_id'].astype(str) == prop_id]
        
        if len(prop_df) == 0:
            raise HTTPException(status_code=404, detail=f"找不到ID为 {prop_id} 的房产")
        
        # 获取第一个匹配的房产
        row = prop_df.iloc[0]
        
        # 使用price_analysis模块计算预测价格和特征重要性
        from price_analysis import (
            predict_property_price, 
            find_comparable_properties,
            generate_price_trends,
            calculate_price_range,
            get_neighborhood_stats,
            calculate_confidence_interval,
            get_model_explanation
        )
        
        # 导入备用数据生成函数
        from price_utils import generate_rule_based_importance, generate_dummy_comparables
        
        # 预测价格和计算特征重要性
        try:
            pred_price, feature_importance = predict_property_price(
                row=row, 
                model=MODEL, 
                feature_cols=FEATURE_COLS, 
                properties_df=PROPERTIES_DF
            )
        except Exception as e:
            print(f"预测价格和计算特征重要性时出错: {e}")
            # 使用实际价格或默认值
            if 'y_label' in row and pd.notna(row['y_label']):
                try:
                    pred_price = float(row['y_label'])
                except:
                    pred_price = 750000
            else:
                pred_price = 750000
                
            # 使用规则生成特征重要性
            feature_importance = generate_rule_based_importance(
                row=row, 
                feature_cols=FEATURE_COLS if FEATURE_COLS else [], 
                pred_price=pred_price
            )
        
        # 查找可比房产
        try:
            comparable_properties = find_comparable_properties(
                row=row,
                prop_id=prop_id,
                properties_df=PROPERTIES_DF
            )
            
            # 确保我们至少有一些可比房产
            if not comparable_properties:
                comparable_properties = generate_dummy_comparables(row, prop_id)
        except Exception as e:
            print(f"查找可比房产时出错: {e}")
            # 生成虚拟可比房产
            comparable_properties = generate_dummy_comparables(row, prop_id)
        
        # 创建属性字典
        features = {}
        for col in row.index:
            if col not in ['prop_id', 'std_address']:
                val = row[col]
                features[col] = float(val) if isinstance(val, (int, float)) and not np.isnan(val) else (
                    str(val) if not pd.isna(val) else None
                )
        
        # 房产面积
        prop_area = float(row.get('prop_area', 100))
        
        try:
            property_detail = PropertyDetail(
                prop_id=str(row['prop_id']),
                address=row['std_address'],
                predicted_price=pred_price,
                features=features,
                feature_importance=feature_importance,
                comparable_properties=comparable_properties,
                # 添加历史价格趋势数据
                price_trends=generate_price_trends(pred_price),
                # 添加价格预测区间
                price_range=calculate_price_range(pred_price),
                # 添加周边区域统计
                neighborhood_stats=get_neighborhood_stats(pred_price, prop_area, row, PROPERTIES_DF),
                # 添加置信区间
                confidence_interval=calculate_confidence_interval(pred_price),
                # 添加更详细的模型解释
                ai_explanation=get_model_explanation(pred_price, feature_importance, FEATURE_COLS)
            )
            
            # 检查并确保feature_importance不为空
            if not property_detail.feature_importance:
                property_detail.feature_importance = generate_rule_based_importance(
                    row=row, 
                    feature_cols=FEATURE_COLS if FEATURE_COLS else [],
                    pred_price=pred_price
                )
            
            # 检查并确保comparable_properties不为空
            if not property_detail.comparable_properties:
                property_detail.comparable_properties = generate_dummy_comparables(row, prop_id)
                
            return convert_numpy_types(property_detail)
            
        except Exception as e:
            print(f"创建PropertyDetail对象时出错: {e}")
            # 创建最基本的PropertyDetail对象
            property_detail = PropertyDetail(
                prop_id=str(row['prop_id']),
                address=row['std_address'],
                predicted_price=pred_price,
                features=features,
                feature_importance=generate_rule_based_importance(row, FEATURE_COLS if FEATURE_COLS else [], pred_price),
                comparable_properties=generate_dummy_comparables(row, prop_id),
                price_trends=generate_price_trends(pred_price),
                price_range=calculate_price_range(pred_price),
                neighborhood_stats=get_neighborhood_stats(pred_price, prop_area),
                confidence_interval=calculate_confidence_interval(pred_price),
                ai_explanation=get_model_explanation(pred_price, [], FEATURE_COLS if FEATURE_COLS else [])
            )
            
            return convert_numpy_types(property_detail)
    
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"获取房产详情出错: {str(e)}")

@app.get("/api/properties/{prop_id}/pdf")
async def generate_property_pdf(prop_id: str):
    """生成并返回指定房产的PDF报告"""
    print(f"开始为房产 {prop_id} 生成PDF报告")
    try:
        # 检查全局数据是否已加载
        if PROPERTIES_DF is None:
            print("错误: 房产数据尚未加载")
            raise HTTPException(status_code=500, detail="房产数据尚未加载")
            
        # 从数据中获取房产详情
        print(f"正在查找房产ID: {prop_id}")
        property_data = PROPERTIES_DF[PROPERTIES_DF["prop_id"].astype(str) == prop_id]
        
        if property_data.empty:
            print(f"错误: 未找到房产ID {prop_id}")
            raise HTTPException(status_code=404, detail="未找到该房产")
        
        print(f"已找到房产记录，开始获取详细信息")
        # 获取完整的房产详情
        try:
            detail = await get_property_detail(prop_id)
            print(f"成功获取房产详情: {detail.address}")
        except Exception as e:
            print(f"获取房产详情失败: {str(e)}")
            raise HTTPException(status_code=500, detail=f"获取房产详情失败: {str(e)}")
        
        # 配置中文字体支持
        print("配置中文字体支持")
        # 在Windows中尝试使用系统字体
        font_path = None
        try:
            if platform.system() == 'Windows':
                # 尝试常见的系统字体路径
                possible_fonts = [
                    "C:/Windows/Fonts/simhei.ttf",  # 黑体
                    "C:/Windows/Fonts/simsun.ttc",  # 宋体
                    "C:/Windows/Fonts/msyh.ttc",    # 微软雅黑
                    "C:/Windows/Fonts/simfang.ttf", # 仿宋
                    "C:/Windows/Fonts/arial.ttf",   # Arial (作为后备)
                ]
                for path in possible_fonts:
                    if os.path.exists(path):
                        font_path = path
                        print(f"找到字体: {path}")
                        break
                
                if font_path is None:
                    print("警告: 未找到任何中文字体，将使用默认字体")
        except Exception as e:
            print(f"字体检测过程出错: {str(e)}")
        
        # 注册字体
        chinese_font_name = 'Helvetica'  # 默认字体
        try:
            if font_path:
                font_name = os.path.basename(font_path).split('.')[0]
                try:
                    pdfmetrics.registerFont(TTFont(font_name, font_path))
                    chinese_font_name = font_name
                    print(f"成功注册字体: {font_name}")
                except Exception as font_error:
                    print(f"字体注册失败: {str(font_error)}，将使用默认字体")
        except Exception as e:
            print(f"字体处理过程出错: {str(e)}")
        
        # 创建一个内存中的PDF文件
        print("创建PDF文档")
        buffer = io.BytesIO()
        try:
            doc = SimpleDocTemplate(buffer, pagesize=A4, topMargin=0.5*inch, bottomMargin=0.5*inch)
            styles = getSampleStyleSheet()
            
            # 自定义中文标题和正文样式
            title_style = ParagraphStyle(
                'ChineseTitle',
                parent=styles['Title'],
                fontName=chinese_font_name
            )
            
            heading2_style = ParagraphStyle(
                'ChineseHeading2',
                parent=styles['Heading2'],
                fontName=chinese_font_name
            )
            
            normal_style = ParagraphStyle(
                'ChineseNormal',
                parent=styles['Normal'],
                fontName=chinese_font_name
            )
            
            elements = []
            
            print("添加PDF内容: 标题")
            # 添加标题
            try:
                title_text = f"房产估价报告: {detail.address}"
                elements.append(Paragraph(title_text, title_style))
                elements.append(Spacer(1, 0.25*inch))
            except Exception as e:
                print(f"添加标题时出错: {str(e)}")
                # 使用简单标题作为后备
                elements.append(Paragraph("房产估价报告", title_style))
                elements.append(Spacer(1, 0.25*inch))
            
            print("添加PDF内容: 基本信息")
            # 添加基本信息
            elements.append(Paragraph("基本信息", heading2_style))
            elements.append(Spacer(1, 0.1*inch))
            
            # 创建基本信息表格数据
            try:
                basic_data = [
                    ["属性", "值"],
                    ["房产ID", str(detail.prop_id)],
                    ["地址", str(detail.address)],
                    ["预测价格", f"¥{detail.predicted_price:,.2f}"],
                ]
                
                # 添加特征值到表格
                for key, value in detail.features.items():
                    if key not in ["prop_id", "address"]:
                        # 格式化特征名称和值
                        formatted_key = str(key).replace("_", " ").title()
                        if isinstance(value, (int, float)) and key != "predicted_price":
                            formatted_value = f"{value:,.2f}" if '.' in str(value) else f"{value:,}"
                        else:
                            formatted_value = str(value)
                        basic_data.append([formatted_key, formatted_value])
            except Exception as e:
                print(f"准备基本信息数据时出错: {str(e)}")
                # 使用简单的基本数据作为后备
                basic_data = [
                    ["属性", "值"],
                    ["房产ID", str(detail.prop_id)],
                    ["地址", str(detail.address)],
                ]
            
            # 将表格数据转换为Paragraph对象以支持中文
            print("格式化表格数据")
            try:
                styled_basic_data = []
                for row in basic_data:
                    styled_row = []
                    for cell in row:
                        try:
                            styled_row.append(Paragraph(str(cell), normal_style))
                        except Exception as cell_error:
                            print(f"处理单元格数据时出错: {cell} - {str(cell_error)}")
                            styled_row.append(Paragraph("数据错误", normal_style))
                    styled_basic_data.append(styled_row)
                
                # 创建并设置表格样式
                basic_table = Table(styled_basic_data, colWidths=[2.5*inch, 3*inch])
                basic_table.setStyle(TableStyle([
                    ('BACKGROUND', (0, 0), (1, 0), colors.gray),
                    ('TEXTCOLOR', (0, 0), (1, 0), colors.whitesmoke),
                    ('ALIGN', (0, 0), (1, 0), 'CENTER'),
                    ('BOTTOMPADDING', (0, 0), (1, 0), 12),
                    ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
                    ('GRID', (0, 0), (-1, -1), 1, colors.black),
                ]))
                
                elements.append(basic_table)
                elements.append(Spacer(1, 0.25*inch))
            except Exception as e:
                print(f"创建基本信息表格时出错: {str(e)}")
                # 跳过表格，添加简单文本
                elements.append(Paragraph("基本信息无法显示", normal_style))
                elements.append(Spacer(1, 0.25*inch))
            
            # 添加特征影响部分
            if detail.feature_importance and len(detail.feature_importance) > 0:
                print("添加PDF内容: 特征影响因素")
                try:
                    elements.append(Paragraph("特征影响因素", heading2_style))
                    elements.append(Spacer(1, 0.1*inch))
                    
                    feature_data = [["特征", "影响值", "影响百分比"]]
                    for feature in detail.feature_importance[:10]:  # 仅显示前10个特征
                        feature_data.append([
                            str(feature.get("name", "")).replace("_", " ").title(),
                            f"{feature.get('value', 0):,.2f}",
                            f"{feature.get('percentage', 0):.2f}%"
                        ])
                    
                    # 将表格数据转换为Paragraph对象以支持中文
                    styled_feature_data = []
                    for row in feature_data:
                        styled_row = []
                        for cell in row:
                            styled_row.append(Paragraph(str(cell), normal_style))
                        styled_feature_data.append(styled_row)
                    
                    feature_table = Table(styled_feature_data, colWidths=[2*inch, 1.5*inch, 1.5*inch])
                    feature_table.setStyle(TableStyle([
                        ('BACKGROUND', (0, 0), (2, 0), colors.gray),
                        ('TEXTCOLOR', (0, 0), (2, 0), colors.whitesmoke),
                        ('ALIGN', (0, 0), (2, 0), 'CENTER'),
                        ('BOTTOMPADDING', (0, 0), (2, 0), 12),
                        ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
                        ('GRID', (0, 0), (-1, -1), 1, colors.black),
                    ]))
                    
                    elements.append(feature_table)
                    elements.append(Spacer(1, 0.25*inch))
                except Exception as e:
                    print(f"添加特征影响部分时出错: {str(e)}")
            
            # 添加可比较房产信息
            if detail.comparable_properties and len(detail.comparable_properties) > 0:
                print("添加PDF内容: 可比较房产")
                try:
                    elements.append(Paragraph("可比较房产", heading2_style))
                    elements.append(Spacer(1, 0.1*inch))
                    
                    comp_data = [["地址", "价格", "差异"]]
                    for comp in detail.comparable_properties[:5]:  # 仅显示前5个可比较房产
                        comp_data.append([
                            str(comp.get("address", "")),
                            f"¥{comp.get('price', 0):,.2f}",
                            f"{comp.get('price_diff_percent', 0):.2f}%"
                        ])
                    
                    # 将表格数据转换为Paragraph对象以支持中文
                    styled_comp_data = []
                    for row in comp_data:
                        styled_row = []
                        for cell in row:
                            styled_row.append(Paragraph(str(cell), normal_style))
                        styled_comp_data.append(styled_row)
                    
                    comp_table = Table(styled_comp_data, colWidths=[3*inch, 1.5*inch, 1*inch])
                    comp_table.setStyle(TableStyle([
                        ('BACKGROUND', (0, 0), (2, 0), colors.gray),
                        ('TEXTCOLOR', (0, 0), (2, 0), colors.whitesmoke),
                        ('ALIGN', (0, 0), (2, 0), 'CENTER'),
                        ('BOTTOMPADDING', (0, 0), (2, 0), 12),
                        ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
                        ('GRID', (0, 0), (-1, -1), 1, colors.black),
                    ]))
                    
                    elements.append(comp_table)
                    elements.append(Spacer(1, 0.25*inch))
                except Exception as e:
                    print(f"添加可比较房产部分时出错: {str(e)}")
            
            # 添加价格区间信息
            if detail.price_range:
                print("添加PDF内容: 价格区间")
                try:
                    elements.append(Paragraph("价格区间", heading2_style))
                    elements.append(Spacer(1, 0.1*inch))
                    
                    price_range_data = [
                        ["最低价格", "预测价格", "最高价格"],
                        [
                            f"¥{detail.price_range.get('min', 0):,.2f}",
                            f"¥{detail.predicted_price:,.2f}",
                            f"¥{detail.price_range.get('max', 0):,.2f}"
                        ]
                    ]
                    
                    # 将表格数据转换为Paragraph对象以支持中文
                    styled_price_range_data = []
                    for row in price_range_data:
                        styled_row = []
                        for cell in row:
                            styled_row.append(Paragraph(str(cell), normal_style))
                        styled_price_range_data.append(styled_row)
                    
                    price_range_table = Table(styled_price_range_data, colWidths=[2*inch, 2*inch, 2*inch])
                    price_range_table.setStyle(TableStyle([
                        ('BACKGROUND', (0, 0), (2, 0), colors.gray),
                        ('TEXTCOLOR', (0, 0), (2, 0), colors.whitesmoke),
                        ('ALIGN', (0, 0), (2, 0), 'CENTER'),
                        ('BOTTOMPADDING', (0, 0), (2, 0), 12),
                        ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
                        ('GRID', (0, 0), (-1, -1), 1, colors.black),
                        ('ALIGN', (0, 1), (2, 1), 'CENTER'),
                    ]))
                    
                    elements.append(price_range_table)
                    elements.append(Spacer(1, 0.25*inch))
                except Exception as e:
                    print(f"添加价格区间部分时出错: {str(e)}")
            
            # 添加报告生成时间
            print("添加PDF内容: 生成时间")
            try:
                from datetime import datetime
                now = datetime.now()
                date_style = ParagraphStyle(
                    "ChineseDateStyle", 
                    parent=normal_style,
                    alignment=1  # 1 = center
                )
                elements.append(Paragraph(f"报告生成时间: {now.strftime('%Y-%m-%d %H:%M:%S')}", date_style))
            except Exception as e:
                print(f"添加生成时间时出错: {str(e)}")
            
            # 构建PDF文档
            print("构建PDF文档")
            doc.build(elements)
            buffer.seek(0)
            
            # 获取PDF内容
            pdf_content = buffer.getvalue()
            
            # 设置文件名
            filename = f"property_report_{prop_id}.pdf"
            
            print(f"PDF生成成功，大小: {len(pdf_content)} 字节")
            
            # 创建Response对象
            response = Response(
                content=pdf_content,
                media_type="application/pdf",
                headers={"Content-Disposition": f"attachment; filename={filename}"}
            )
            
            return response
        except Exception as e:
            print(f"PDF生成过程中出错: {str(e)}")
            import traceback
            traceback.print_exc()
            raise HTTPException(status_code=500, detail=f"PDF生成过程中出错: {str(e)}")
            
    except HTTPException as he:
        # 重新抛出HTTP异常
        raise he
    except Exception as e:
        print(f"生成PDF报告时出现未预期错误: {str(e)}")
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=f"生成PDF报告时出错: {str(e)}")

# 添加一个简化版的PDF生成API端点
@app.get("/api/properties/{prop_id}/pdf-simple")
async def generate_simple_property_pdf(prop_id: str):
    """生成并返回指定房产的简化PDF报告"""
    print(f"开始为房产 {prop_id} 生成简化PDF报告")
    try:
        # 检查全局数据是否已加载
        if PROPERTIES_DF is None:
            print("错误: 房产数据尚未加载")
            raise HTTPException(status_code=500, detail="房产数据尚未加载")
            
        # 从数据中获取房产详情
        print(f"正在查找房产ID: {prop_id}")
        property_data = PROPERTIES_DF[PROPERTIES_DF["prop_id"].astype(str) == prop_id]
        
        if property_data.empty:
            print(f"错误: 未找到房产ID {prop_id}")
            raise HTTPException(status_code=404, detail="未找到该房产")
        
        # 不使用get_property_detail函数，直接从数据中获取基本信息
        row = property_data.iloc[0]
        address = str(row.get('address', '未知地址'))
        
        # 使用简单的reportlab创建PDF
        buffer = io.BytesIO()
        
        # 创建一个简单的PDF文档，避免复杂的格式和字体问题
        from reportlab.pdfgen import canvas
        
        # 设置页面大小为A4
        c = canvas.Canvas(buffer, pagesize=A4)
        
        # 添加标题
        title = "房产估价报告"
        c.setFont("Helvetica-Bold", 18)
        c.drawCentredString(A4[0]/2, A4[1] - 50, title)
        
        # 添加房产ID和地址
        c.setFont("Helvetica", 12)
        c.drawString(50, A4[1] - 100, f"房产ID: {prop_id}")
        c.drawString(50, A4[1] - 120, f"地址: {address}")
        
        # 添加预测价格（如果有）
        predicted_price = row.get('predicted_price', 0)
        if isinstance(predicted_price, (int, float)):
            price_str = f"¥{predicted_price:,.2f}"
        else:
            price_str = str(predicted_price)
        c.drawString(50, A4[1] - 140, f"预测价格: {price_str}")
        
        # 添加主要特征
        y_pos = A4[1] - 180
        c.drawString(50, y_pos, "主要特征:")
        y_pos -= 20
        
        feature_count = 0
        for col in property_data.columns:
            if col not in ['prop_id', 'address', 'predicted_price'] and feature_count < 10:
                try:
                    value = row[col]
                    if pd.notna(value):  # 只显示非空值
                        if isinstance(value, (int, float)):
                            value_str = f"{value:,.2f}" if '.' in str(value) else f"{value:,}"
                        else:
                            value_str = str(value)
                        
                        feature_name = col.replace('_', ' ').title()
                        c.drawString(70, y_pos, f"{feature_name}: {value_str}")
                        y_pos -= 15
                        feature_count += 1
                except Exception as e:
                    print(f"处理特征 {col} 时出错: {str(e)}")
        
        # 添加生成时间
        from datetime import datetime
        now = datetime.now()
        date_str = now.strftime('%Y-%m-%d %H:%M:%S')
        c.setFont("Helvetica-Italic", 10)
        c.drawString(50, 50, f"报告生成时间: {date_str}")
        
        # 保存PDF
        c.save()
        buffer.seek(0)
        
        # 获取PDF内容
        pdf_content = buffer.getvalue()
        
        # 设置文件名
        filename = f"property_report_simple_{prop_id}.pdf"
        
        print(f"简化PDF生成成功，大小: {len(pdf_content)} 字节")
        
        # 创建Response对象
        response = Response(
            content=pdf_content,
            media_type="application/pdf",
            headers={"Content-Disposition": f"attachment; filename={filename}"}
        )
        
        return response
        
    except Exception as e:
        print(f"生成简化PDF报告时出错: {str(e)}")
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=f"生成简化PDF报告时出错: {str(e)}")

# 模型管理相关的API
@app.get("/api/models", response_model=ModelListResponse)
async def list_models():
    """获取所有可用模型的列表"""
    try:
        if not MODELS_AVAILABLE:
            # 如果模型模块不可用，则返回空列表
            return ModelListResponse(models=[])
        
        # 使用ModelFactory获取所有模型
        models = ModelFactory.list_models("../model")
        
        # 对模型按创建时间倒序排序
        models = sorted(models, key=lambda x: os.path.getmtime(x["path"]) if "path" in x else 0, reverse=True)
        
        return ModelListResponse(models=models)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"获取模型列表失败: {str(e)}")

@app.post("/api/models/train", response_model=ModelTrainingResponse)
async def train_model(request: ModelTrainingRequest):
    """训练新模型"""
    try:
        if not MODELS_AVAILABLE:
            raise HTTPException(status_code=400, detail="模型模块不可用，无法训练新模型")
        
        # 读取数据
        data_path = "../resources/house_samples_features.csv"
        if not os.path.exists(data_path):
            raise HTTPException(status_code=404, detail=f"数据文件不存在: {data_path}")
        
        # 导入train_and_evaluate_model函数
        sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
        from train_models import train_and_evaluate_model
        
        # 训练模型
        metrics = train_and_evaluate_model(
            model_type=request.model_type,
            data_file=data_path,
            output_dir="../model",
            test_size=request.test_size,
            random_state=request.random_state,
            params=request.params
        )
        
        # 构建响应
        model_path = f"../model/{request.model_type}_model.joblib"
        
        return ModelTrainingResponse(
            success=True,
            message=f"{request.model_type}模型训练成功",
            metrics=metrics,
            model_path=model_path
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"模型训练失败: {str(e)}")

@app.get("/api/models/{model_type}/params")
async def get_model_params(model_type: str):
    """获取指定模型类型的默认参数"""
    try:
        if not MODELS_AVAILABLE:
            raise HTTPException(status_code=400, detail="模型模块不可用，无法获取模型参数")
        
        # 创建临时模型实例以获取默认参数
        model = ModelFactory.create_model(model_type)
        
        return {
            "model_type": model_type,
            "params": model.get_params()
        }
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"获取模型参数失败: {str(e)}")

@app.delete("/api/models/{model_path:path}")
async def delete_model(model_path: str):
    """删除指定的模型文件"""
    try:
        full_path = f"../model/{model_path}"
        if not os.path.exists(full_path):
            raise HTTPException(status_code=404, detail=f"模型文件不存在: {model_path}")
        
        # 删除模型文件
        os.remove(full_path)
        
        # 尝试删除关联的元数据文件
        meta_path = os.path.splitext(full_path)[0] + "_meta.json"
        if os.path.exists(meta_path):
            os.remove(meta_path)
        
        return {"success": True, "message": f"模型 {model_path} 已删除"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"删除模型失败: {str(e)}")

@app.post("/api/models/{model_path:path}/activate")
async def activate_model(model_path: str):
    """激活指定的模型（设置为当前使用的模型）"""
    global MODEL, FEATURE_COLS
    
    try:
        full_path = f"../model/{model_path}"
        if not os.path.exists(full_path):
            raise HTTPException(status_code=404, detail=f"模型文件不存在: {model_path}")
        
        if not MODELS_AVAILABLE:
            # 使用传统方式加载模型
            MODEL = joblib.load(full_path)
            
            # 尝试加载特征列
            feature_cols_path = Path("../model/feature_cols.joblib")
            if feature_cols_path.exists():
                FEATURE_COLS = joblib.load(feature_cols_path)
        else:
            # 使用模型工厂加载模型
            MODEL = ModelFactory.load_model(full_path)
            
            # 从模型中获取特征列
            if hasattr(MODEL, 'feature_names') and MODEL.feature_names is not None:
                FEATURE_COLS = MODEL.feature_names
        
        return {"success": True, "message": f"模型 {model_path} 已激活"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"激活模型失败: {str(e)}")

# Vercel部署支持
from mangum import Mangum
handler = Mangum(app)

if __name__ == "__main__":
    import uvicorn
    port = int(os.environ.get("PORT", 8000))
    uvicorn.run("main:app", host="127.0.0.1", port=port, reload=False)  # 设置reload=False
##
#python main.py