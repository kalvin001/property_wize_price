from fastapi import APIRouter, HTTPException, BackgroundTasks, UploadFile, File, Form, Depends
from fastapi.responses import FileResponse
from pydantic import BaseModel
from typing import List, Dict, Any, Optional
import os
import tempfile
import json
import shutil
from datetime import datetime
from database.project_manager import project_manager

# API路由
router = APIRouter(prefix="/api/projects", tags=["项目管理"])

# 数据模型
class ProjectCreate(BaseModel):
    name: str
    description: Optional[str] = None

class ProjectUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None

class ProjectScan(BaseModel):
    project_id: Optional[int] = None
    name: Optional[str] = None

class ProjectResponse(BaseModel):
    id: int
    name: str
    description: Optional[str] = None
    created_at: datetime
    updated_at: datetime
    config: Optional[Dict[str, Any]] = None

# API接口
@router.get("/", response_model=List[ProjectResponse])
async def get_all_projects():
    """获取所有项目"""
    projects = project_manager.get_all_projects()
    return projects

@router.post("/", response_model=ProjectResponse)
async def create_project(project_data: ProjectCreate):
    """创建新项目"""
    project = project_manager.create_project(
        name=project_data.name,
        description=project_data.description
    )
    return project

@router.get("/{project_id}", response_model=ProjectResponse)
async def get_project(project_id: int):
    """获取项目详情"""
    project = project_manager.get_project(project_id)
    if not project:
        raise HTTPException(status_code=404, detail=f"未找到ID为{project_id}的项目")
    return project

@router.put("/{project_id}", response_model=ProjectResponse)
async def update_project(project_id: int, project_data: ProjectUpdate):
    """更新项目"""
    update_data = project_data.dict(exclude_unset=True)
    project = project_manager.update_project(project_id, **update_data)
    if not project:
        raise HTTPException(status_code=404, detail=f"未找到ID为{project_id}的项目")
    return project

@router.delete("/{project_id}")
async def delete_project(project_id: int):
    """删除项目"""
    success = project_manager.delete_project(project_id)
    if not success:
        raise HTTPException(status_code=404, detail=f"未找到ID为{project_id}的项目")
    return {"message": f"项目ID={project_id}已成功删除"}

@router.post("/scan", response_model=ProjectResponse)
async def scan_project(scan_data: ProjectScan, background_tasks: BackgroundTasks):
    """扫描项目结构"""
    try:
        project = project_manager.scan_project_structure(
            project_name=scan_data.name,
            project_id=scan_data.project_id
        )
        return project
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"扫描项目时发生错误: {str(e)}")

@router.get("/{project_id}/export")
async def export_project(project_id: int, background_tasks: BackgroundTasks):
    """导出项目为ZIP文件"""
    try:
        # 创建临时目录用于导出
        temp_dir = tempfile.mkdtemp()
        output_path = os.path.join(temp_dir, f"project_{project_id}_export.zip")
        
        # 执行导出
        project_manager.export_project(project_id, output_path)
        
        # 设置清理函数
        def cleanup():
            if os.path.exists(temp_dir):
                shutil.rmtree(temp_dir)
                
        # 添加到后台任务，在响应发送后执行清理
        background_tasks.add_task(cleanup)
        
        # 返回文件
        return FileResponse(
            path=output_path,
            filename=f"project_{project_id}_export.zip",
            media_type="application/zip"
        )
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"导出项目时发生错误: {str(e)}")

@router.post("/import")
async def import_project(
    file: UploadFile = File(...),
    background_tasks: BackgroundTasks = BackgroundTasks()
):
    """从ZIP文件导入项目"""
    try:
        # 创建临时目录
        temp_dir = tempfile.mkdtemp()
        temp_file = os.path.join(temp_dir, "import.zip")
        
        # 保存上传的文件
        with open(temp_file, "wb") as f:
            content = await file.read()
            f.write(content)
        
        # 导入项目
        project = project_manager.import_project(temp_file)
        
        # 设置清理函数
        def cleanup():
            if os.path.exists(temp_dir):
                shutil.rmtree(temp_dir)
                
        # 添加到后台任务，在响应发送后执行清理
        background_tasks.add_task(cleanup)
        
        return {
            "message": "项目导入成功",
            "project_id": project.id,
            "project_name": project.name
        }
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"导入项目时发生错误: {str(e)}")

# 添加到主应用中
def init_project_api(app):
    """初始化项目管理API"""
    app.include_router(router) 